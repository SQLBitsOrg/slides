USE [Contoso DQ]
GO

DROP TABLE IF EXISTS Agg.SalesByYear 
DROP TABLE IF EXISTS Agg.SalesByCustomerAndYear
DROP TABLE IF EXISTS Agg.SalesByDate 
DROP TABLE IF EXISTS Agg.SalesByCustomerAndDate
DROP SCHEMA IF EXISTS Agg
GO

CREATE SCHEMA Agg
GO

--
--	This query groups by Year and aggregates the Quantity column
--
SELECT Date.[Year], 
       SUM (Sales.Quantity) AS SumOfQuantity,
	   SUM (Sales.Quantity * Sales.[Net Price]) AS SumLineAmount
INTO   Agg.SalesByYear 
FROM   dbo.Sales 
       LEFT OUTER JOIN dbo.Date 
                    ON Date.Date = Sales.[Order date] 
GROUP  BY Date.[Year]
GO

--
--	This query groups by Order Date and aggregates the Quantity column
--
SELECT Sales.[Order date], 
       SUM (Sales.Quantity) AS SumOfQuantity,
	   SUM (Sales.Quantity * Sales.[Net Price]) AS SumLineAmount
INTO   Agg.SalesByDate
FROM   dbo.Sales 
       LEFT OUTER JOIN dbo.Date 
                    ON Date.Date = Sales.[Order date] 
GROUP  BY Sales.[Order date]
GO

--
--	This query groups by Year and CustomerKey and aggregates the Quantity column
--
SELECT Date.[Year],  
       Sales.Customerkey, 
       SUM (Sales.Quantity) AS SumOfQuantity,
	   SUM (Sales.Quantity * Sales.[Net Price]) AS SumLineAmount
INTO   Agg.SalesByCustomerAndYear 
FROM   dbo.Sales 
       LEFT OUTER JOIN dbo.Date 
                    ON Date.Date = Sales.[Order date] 
GROUP  BY [Year], 
          Sales.Customerkey  

GO

--
--	This query groups by Order Date and CustomerKey and aggregates the Quantity column
--
SELECT Sales.[Order date],  
       Sales.Customerkey, 
       SUM (Sales.Quantity) AS SumOfQuantity,
	   SUM (Sales.Quantity * Sales.[Net Price]) AS SumLineAmount
INTO   Agg.SalesByCustomerAndDate
FROM   dbo.Sales 
       LEFT OUTER JOIN dbo.Date 
                    ON Date.Date = Sales.[Order date] 
GROUP  BY Sales.[Order date],  
          Sales.Customerkey  

GO

/*
-- Three years: 2007..2009
-- Let us delete some of them
ALTER   VIEW [dbo].[Sales] AS
SELECT 
        Orders.OrderKey AS [Order Number],
        OrderRows.[Line Number] AS [Line Number],
        Orders.[Order Date],
        Orders.[Delivery Date],
        Orders.CustomerKey,
        Orders.StoreKey,
        OrderRows.ProductKey,
        OrderRows.Quantity,
        OrderRows.[Unit Price],
        OrderRows.[Net Price],
        OrderRows.[Unit Cost],
        Orders.[Currency Code],
        [CurrencyExchange].Exchange AS [Exchange Rate]
    FROM
        [Data].Orders  
            LEFT OUTER JOIN [Data].OrderRows
                ON Orders.OrderKey = OrderRows.OrderKey
            LEFT OUTER JOIN [Data].[CurrencyExchange]
                ON 
                    [CurrencyExchange].Date = Orders.[Order Date] AND
                    [CurrencyExchange].[ToCurrency] = Orders.[Currency Code] AND
                    [CurrencyExchange].[FromCurrency] = 'USD'
    WHERE YEAR ( Orders.[Order Date] ) <> 2017
*/                    
GO

