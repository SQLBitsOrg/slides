We use a Contoso DQ database on SQL Server. 
You can use Contoso 10k from https://github.com/sql-bi/Contoso-Data-Generator/releases and execute the "Prepare Contoso DQ.sql" batch in this folder.