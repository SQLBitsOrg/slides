/****************************************************************************/
/*                SQLBits 2024, Farnborough, 22.03.2024                     */
/*                  Author: Milos Radivojevic                               */
/*                 Session: When to Stop Tuning a Query?                    */
/****************************************************************************/
/*                 Query with large tables - Using hints                    */
/*                                                                          */
/****************************************************************************/

USE xSQLPASS2022;
GO

--initial query
SELECT * FROM dbo.Orders o
INNER JOIN dbo.OrderDetails od ON o.OrderId = od.OrderId
WHERE o.CustomerId = 987004 
ORDER BY od.Cols;

--workaround 1 - the LOOP hint
SELECT * FROM dbo.Orders o
INNER LOOP JOIN dbo.OrderDetails od ON o.OrderId = od.OrderId
WHERE o.CustomerId = 987004
ORDER BY od.Cols;
/*
10 GB memory grant!!!
*/
--when it's invoked in 200 parallel sessions
--SQLQueryStress Tool 

--2. hint - MAX_GRANT_PERCENT
SELECT * FROM dbo.Orders o
INNER LOOP JOIN dbo.OrderDetails od ON o.OrderId = od.OrderId
WHERE o.CustomerId = 987004
ORDER BY od.Cols
OPTION (MAX_GRANT_PERCENT = 0.1);
/*
10 MB memory grant
*/
--3. hint - MAXDOP 1
SELECT * FROM dbo.Orders o
INNER LOOP JOIN dbo.OrderDetails od ON o.OrderId = od.OrderId
WHERE o.CustomerId = 987004
ORDER BY od.Cols
OPTION (MAX_GRANT_PERCENT = 0.1, MAXDOP 1);


