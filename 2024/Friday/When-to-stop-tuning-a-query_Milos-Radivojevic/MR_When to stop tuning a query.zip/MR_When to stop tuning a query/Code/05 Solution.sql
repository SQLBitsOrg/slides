/****************************************************************************/
/*                SQLBits 2024, Farnborough, 22.03.2024                     */
/*                  Author: Milos Radivojevic                               */
/*                 Session: When to Stop Tuning a Query?                    */
/****************************************************************************/
/*                Query with large tables - updating statistics             */
/*                                                                          */
/****************************************************************************/



USE xSQLPASS2022;
GO
--a proper solution
UPDATE STATISTICS Orders ix1 WITH SAMPLE 50 PERCENT, MAXDOP = 8
UPDATE STATISTICS OrderDetails ix1 WITH SAMPLE 20 PERCENT, MAXDOP = 8
GO

SELECT * FROM dbo.Orders o
INNER JOIN dbo.OrderDetails od ON o.OrderId = od.OrderId
WHERE o.CustomerId = 987004
ORDER BY od.Cols;

