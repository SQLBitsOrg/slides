/****************************************************************************/
/*                SQLBits 2024, Farnborough, 22.03.2024                     */
/*                  Author: Milos Radivojevic                               */
/*                 Session: When to Stop Tuning a Query?                    */
/****************************************************************************/
/*          Query with large tables - Using cardinality estimation tricks   */
/*                                                                          */
/****************************************************************************/


USE xSQLPASS2022;
GO
--ensure that CL is 140 (SQL Server 2017)
ALTER DATABASE xSQLPASS2022 SET COMPATIBILITY_LEVEL = 140;
GO
DECLARE @Orders TABLE(
	OrderID INT NOT NULL PRIMARY KEY,
	CustomerID INT NOT NULL,
	Cols CHAR(100) NOT NULL
	)

INSERT INTO @Orders(OrderID, CustomerID, Cols)
SELECT OrderID, CustomerID, Cols
FROM dbo.Orders o
WHERE o.CustomerId = 987004;

SELECT * FROM @Orders o
INNER JOIN dbo.OrderDetails od ON o.OrderId = od.OrderId
INNER JOIN dbo.OrderDetails od2 ON od.OrderId = od2.OrderId
ORDER BY od2.Cols
GO
--upgrade to SQL 2019
ALTER DATABASE xSQLPASS2022 SET COMPATIBILITY_LEVEL = 150;
GO
DECLARE @Orders TABLE(
	OrderID INT NOT NULL PRIMARY KEY,
	CustomerID INT NOT NULL,
	Cols CHAR(100) NOT NULL
	)

INSERT INTO @Orders(OrderID, CustomerID, Cols)
SELECT OrderID, CustomerID, Cols
FROM dbo.Orders o
WHERE o.CustomerId = 987004;

SELECT * FROM @Orders o
INNER JOIN dbo.OrderDetails od ON o.OrderId = od.OrderId
INNER JOIN dbo.OrderDetails od2 ON od.OrderId = od2.OrderId
ORDER BY od2.Cols
GO

/*
workaround is broken!
how to fix it?
with a new hint DISABLE_DEFERRED_COMPILATION_TV;
*/
DECLARE @Orders TABLE(
	OrderID INT NOT NULL PRIMARY KEY,
	CustomerID INT NOT NULL,
	Cols CHAR(100) NOT NULL
	)

INSERT INTO @Orders(OrderID, CustomerID, Cols)
SELECT OrderID, CustomerID, Cols
FROM dbo.Orders o
WHERE o.CustomerId = 987004;

SELECT * FROM @Orders o
INNER JOIN dbo.OrderDetails od ON o.OrderId = od.OrderId
INNER JOIN dbo.OrderDetails od2 ON od.OrderId = od2.OrderId
ORDER BY od2.Cols
OPTION(USE HINT('DISABLE_DEFERRED_COMPILATION_TV'));