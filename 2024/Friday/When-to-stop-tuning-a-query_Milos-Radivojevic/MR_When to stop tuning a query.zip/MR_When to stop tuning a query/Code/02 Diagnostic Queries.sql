/****************************************************************************/
/*                SQLBits 2024, Farnborough, 22.03.2024                     */
/*                  Author: Milos Radivojevic                               */
/*                 Session: When to Stop Tuning a Query?                    */
/****************************************************************************/
/*                            Diagnostic Queries                            */
/*                                                                          */
/****************************************************************************/

SELECT r.wait_time, r.wait_type, r.total_elapsed_time, DB_NAME(r.database_id), r.cpu_time, st.text
FROM sys.dm_exec_requests r 
	INNER JOIN sys.dm_exec_connections c ON r.connection_id = c.connection_id 
	OUTER APPLY sys.dm_exec_sql_text(r.sql_handle) st
WHERE r.wait_type NOT IN ('SP_SERVER_DIAGNOSTICS_SLEEP','WAITFOR')
ORDER BY r.wait_time DESC;

SELECT mg.granted_memory_kb, mg.required_memory_kb, mg.max_used_memory_kb, mg.session_id, t.text
FROM sys.dm_exec_query_memory_grants AS mg
	CROSS APPLY sys.dm_exec_sql_text(mg.sql_handle) AS t
ORDER BY 1 DESC
 