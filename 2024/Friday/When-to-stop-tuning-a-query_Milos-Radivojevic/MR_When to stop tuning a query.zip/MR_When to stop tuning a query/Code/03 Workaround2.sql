/****************************************************************************/
/*                SQLBits 2024, Farnborough, 22.03.2024                     */
/*                  Author: Milos Radivojevic                               */
/*                 Session: When to Stop Tuning a Query?                    */
/****************************************************************************/
/*          Query with large tables - Using cardinality estimation tricks   */
/*                                                                          */
/****************************************************************************/

USE xSQLPASS2022;
GO
--initial query
SELECT * FROM dbo.Orders o
INNER JOIN dbo.OrderDetails od ON o.OrderId = od.OrderId
WHERE o.CustomerId = 987004
ORDER BY od.Cols;

--workaround 2
DECLARE @Orders TABLE(
	OrderID INT NOT NULL PRIMARY KEY,
	CustomerID INT NOT NULL,
	Cols CHAR(100) NOT NULL
	)

INSERT INTO @Orders(OrderID, CustomerID, Cols)
SELECT OrderID, CustomerID, Cols
FROM dbo.Orders o
WHERE o.CustomerId = 987004

SELECT * FROM @Orders o
INNER JOIN dbo.OrderDetails od ON o.OrderId=od.OrderId
ORDER BY od.Cols

/*
check the execution plan
*/
