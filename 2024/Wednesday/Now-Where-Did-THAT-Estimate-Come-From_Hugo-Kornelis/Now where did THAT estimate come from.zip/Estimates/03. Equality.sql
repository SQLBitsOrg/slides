USE EstimateDemo;
GO

-- Value that exists in the statistics
SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID = 738
OPTION (RECOMPILE);     -- To prevent auto-parameterization
GO

-- Nonexisting value - use inclusion and uniformity assumptions
SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID = 737
OPTION (RECOMPILE);     -- To prevent auto-parameterization
GO


-- Playing tricks with the inclusion assumption
SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID IN (736, 737)
OPTION (RECOMPILE);
GO
SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID IN (732, 733, 734, 735, 736, 737)
OPTION (RECOMPILE);
GO
SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID IN (731, 732, 733, 734, 735, 736, 737)
OPTION (RECOMPILE);
GO
SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID IN (727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737)
OPTION (RECOMPILE);
GO

-- Same thing on the old cardinalty estimator.
SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID = 737
OPTION (RECOMPILE, QUERYTRACEON 9481);
GO
SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID IN (736, 737)
OPTION (RECOMPILE, QUERYTRACEON 9481);
GO
SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID IN (732, 733, 734, 735, 736, 737)
OPTION (RECOMPILE, QUERYTRACEON 9481);
GO
SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID IN (731, 732, 733, 734, 735, 736, 737)
OPTION (RECOMPILE, QUERYTRACEON 9481);
GO
SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID IN (727, 728, 729, 730, 731, 732, 733, 734, 735, 736, 737)
OPTION (RECOMPILE, QUERYTRACEON 9481);
GO
