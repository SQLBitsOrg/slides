USE AdventureWorks2017;
GO


-- Table variables: No statistics, so hard to estimate the row count
DECLARE @MyTable AS TABLE (BusinessEntityID int NOT NULL PRIMARY KEY);

INSERT  @MyTable(BusinessEntityID)
SELECT  BusinessEntityID
FROM    HumanResources.Employee;


-- Check the execution plans to see the rowcounts
SELECT  COUNT(*)
FROM    @MyTable;

SELECT  COUNT(*)
FROM    @MyTable
OPTION (RECOMPILE);
GO


-- This also affects table-valued parameters
IF EXISTS
   (SELECT      *
    FROM        sys.objects
    WHERE       object_id = OBJECT_ID(N'dbo.CountEm')
    AND         type IN (N'P', N'PC'))
        BEGIN;
            DROP PROCEDURE dbo.CountEm;
        END;

IF EXISTS
   (SELECT      *
    FROM        sys.types AS st
    INNER JOIN  sys.schemas AS ss
          ON    st.schema_id = ss.schema_id
    WHERE       st.name = N'TabVarDemo'
    AND         ss.name = N'dbo')
        BEGIN;
            DROP TYPE dbo.TabVarDemo;
        END;

CREATE TYPE dbo.TabVarDemo
AS TABLE (BusinessEntityID int NOT NULL PRIMARY KEY);
GO

CREATE PROCEDURE dbo.CountEm (@InTable dbo.TabVarDemo READONLY)
AS
SELECT  COUNT(*)
FROM    @InTable;
GO



DECLARE @MyTable AS dbo.TabVarDemo;

INSERT  @MyTable(BusinessEntityID)
SELECT  BusinessEntityID
FROM    HumanResources.Employee;

EXECUTE dbo.CountEm @MyTable;

DELETE TOP(100) FROM @MyTable;

EXECUTE dbo.CountEm @MyTable;
GO





-- Multi-statement user-defined functions: Also hard to estimate
IF EXISTS (SELECT * FROM sys.objects WHERE name = 'GetAllProjectedWages')
BEGIN;
  DROP FUNCTION dbo.GetAllProjectedWages;
END;
go
CREATE FUNCTION dbo.GetAllProjectedWages
    (@HoursPerYear      int,
     @FactorSalesPerson decimal(5, 3),
     @FactorCommission  decimal(5, 3),
     @FactorSalesYTD    decimal(5, 3),
     @FactorSalaried1   decimal(5, 3),
     @FactorSalaried0   decimal(5, 3))
RETURNS @ProjectedWages table
    (BusinessEntityID int          NOT NULL PRIMARY KEY,
     JobTitle         nvarchar(50) NOT NULL,
     FirstName        nvarchar(50) NOT NULL,
     LastName         nvarchar(50) NOT NULL,
     ProjectedWage    money        NOT NULL)
AS
BEGIN;
    WITH EmployeePayRanked
      AS (SELECT    BusinessEntityID,
                    Rate,
                    RANK() OVER (PARTITION BY BusinessEntityID ORDER BY RateChangeDate DESC) AS rn
          FROM      HumanResources.EmployeePayHistory)
    INSERT INTO @ProjectedWages (BusinessEntityID,
                                 JobTitle,
                                 FirstName,
                                 LastName,
                                 ProjectedWage)
    SELECT      e.BusinessEntityID,
                e.JobTitle,
                p.FirstName,
                p.LastName,
                CAST(CASE WHEN sp.BusinessEntityID IS NOT NULL
                              THEN @HoursPerYear * (ep.Rate * @FactorSalesPerson) + (sp.CommissionPct * @FactorCommission)
                                   * (sp.SalesYTD * @FactorSalesYTD)
                          WHEN e.SalariedFlag = 1
                              THEN @HoursPerYear * (ep.Rate * @FactorSalaried1)
                          ELSE @HoursPerYear * (ep.Rate * @FactorSalaried0)
                     END AS money)
    FROM        HumanResources.Employee AS e
    INNER JOIN  Person.Person           AS p
       ON       p.BusinessEntityID  = e.BusinessEntityID
    INNER JOIN  EmployeePayRanked       AS ep
       ON       ep.BusinessEntityID = e.BusinessEntityID
       AND      ep.rn               = 1
    LEFT JOIN   Sales.SalesPerson       AS sp
      ON        sp.BusinessEntityID = e.BusinessEntityID;

    RETURN;
END;
GO




SET STATISTICS IO ON;
GO

SELECT     ed.DepartmentID,
           SUM(w.ProjectedWage) AS "Projected Wage"
FROM       dbo.GetAllProjectedWages(1800, 0.75, 1.25, 1.5, 1, 1.03) AS w
INNER JOIN HumanResources.EmployeeDepartmentHistory AS ed
      ON   ed.BusinessEntityID = w.BusinessEntityID
      AND  ed.EndDate IS NULL
GROUP BY   ed.DepartmentID
ORDER BY   ed.DepartmentID
OPTION (USE HINT ('QUERY_OPTIMIZER_COMPATIBILITY_LEVEL_110'));
--OPTION (USE HINT ('DISABLE_INTERLEAVED_EXECUTION_TVF'));
GO
