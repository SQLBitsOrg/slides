USE EstimateDemo;
GO

DBCC SHOW_STATISTICS([dbo.DemoTable1], ix_Demo1_ProductID) WITH HISTOGRAM;
DBCC SHOW_STATISTICS([dbo.DemoTable2], ix_Demo2_ProductID) WITH HISTOGRAM;
GO


SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID BETWEEN 750 AND 760
OPTION (RECOMPILE);

SELECT  COUNT(*)
FROM    dbo.DemoTable2
WHERE   ProductID BETWEEN 750 AND 760
OPTION (RECOMPILE);
GO

-- I use a weird SUM instead of COUNT
-- to circumvent an optimization that would ruin my demo
SELECT     SUM(d1.SalesOrderDetailID - d2.SalesOrderDetailID)
FROM       dbo.DemoTable1 AS d1
INNER JOIN dbo.DemoTable2 AS d2
      ON   d2.ProductID = d1.ProductID
WHERE      d1.ProductID BETWEEN 750 AND 760
--AND        d2.ProductID BETWEEN 750 AND 760   -- Uncommenting doesn't change the result,
OPTION (RECOMPILE,                              -- the optimizer infers this anyway.
        USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'));

SELECT     SUM(d1.SalesOrderDetailID - d2.SalesOrderDetailID)
FROM       dbo.DemoTable1 AS d1
INNER JOIN dbo.DemoTable2 AS d2
      ON   d2.ProductID = d1.ProductID
WHERE      d1.ProductID BETWEEN 750 AND 760
--AND        d2.ProductID BETWEEN 750 AND 760   -- Uncommenting doesn't change the result,
OPTION (RECOMPILE,                              -- the optimizer infers this anyway.
        USE HINT ('FORCE_DEFAULT_CARDINALITY_ESTIMATION'));
GO


-- Estimated plan only!!!
SELECT     SUM(d1.SalesOrderDetailID - d2.SalesOrderDetailID)
FROM       dbo.DemoTable1 AS d1
INNER JOIN dbo.DemoTable2 AS d2
      ON   d2.ProductID > d1.ProductID
WHERE      d1.ProductID BETWEEN 750 AND 760
AND        d2.ProductID BETWEEN 750 AND 760
OPTION (RECOMPILE,
        USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'));

SELECT     SUM(d1.SalesOrderDetailID - d2.SalesOrderDetailID)
FROM       dbo.DemoTable1 AS d1
INNER JOIN dbo.DemoTable2 AS d2
      ON   d2.ProductID > d1.ProductID
WHERE      d1.ProductID BETWEEN 750 AND 760
AND        d2.ProductID BETWEEN 750 AND 760
OPTION (RECOMPILE,
        USE HINT ('FORCE_DEFAULT_CARDINALITY_ESTIMATION'));
GO


SELECT      COUNT(*)
FROM        dbo.DemoTable1 AS d1
INNER JOIN  dbo.DemoTable2 AS d2
   ON       d2.ProductID = d1.ProductID
   AND      d2.SalesOrderDetailID
                         = d1.SalesOrderDetailID
OPTION (RECOMPILE,
        USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'));
GO

-- On SQL Server 2012, the estimate for the query above changes (a lot!!) when these statistics exist:
CREATE STATISTICS stat_DemoTable1_ProductID_SalesOrderDetailID ON dbo.DemoTable1 (ProductID, SalesOrderDetailID);
CREATE STATISTICS stat_DemoTable2_ProductID_SalesOrderDetailID ON dbo.DemoTable2 (ProductID, SalesOrderDetailID);

SELECT      COUNT(*)
FROM        dbo.DemoTable1 AS d1
INNER JOIN  dbo.DemoTable2 AS d2
   ON       d2.ProductID = d1.ProductID
   AND      d2.SalesOrderDetailID
                         = d1.SalesOrderDetailID
OPTION (RECOMPILE,
        USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'));

-- Clean up after use...
DROP STATISTICS dbo.DemoTable1.stat_DemoTable1_ProductID_SalesOrderDetailID;
DROP STATISTICS dbo.DemoTable2.stat_DemoTable2_ProductID_SalesOrderDetailID;
GO

SELECT      COUNT(*)
FROM        dbo.DemoTable1 AS d1
INNER JOIN  dbo.DemoTable2 AS d2
   ON       d2.ProductID = d1.ProductID
   AND      d2.SalesOrderDetailID
                         = d1.SalesOrderDetailID
OPTION (RECOMPILE,
        USE HINT ('FORCE_DEFAULT_CARDINALITY_ESTIMATION'));
GO


SELECT      COUNT(*)
FROM        dbo.DemoTable1 AS d1
INNER JOIN  dbo.DemoTable2 AS d2
   ON       d2.ProductID = d1.ProductID
WHERE       d1.SalesOrderDetailID > 15
AND         d2.SalesOrderDetailID < 20
OPTION (RECOMPILE,
        USE HINT ('FORCE_LEGACY_CARDINALITY_ESTIMATION'));

SELECT      COUNT(*)
FROM        dbo.DemoTable1 AS d1
INNER JOIN  dbo.DemoTable2 AS d2
   ON       d2.ProductID = d1.ProductID
WHERE       d1.SalesOrderDetailID > 15
AND         d2.SalesOrderDetailID < 20
OPTION (RECOMPILE,
        USE HINT ('FORCE_DEFAULT_CARDINALITY_ESTIMATION'));
GO
