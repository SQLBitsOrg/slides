USE EstimateDemo;
GO

DECLARE @ProductID int = 820;

SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID = @ProductID;
GO

-- Don't forget to switch off the execution plan plus run-time statistics!
CREATE TABLE dbo.OneVariable
   (KeyCol int NOT NULL IDENTITY,
    DataCol int NOT NULL,
    CONSTRAINT PK_OneVariable
        PRIMARY KEY (KeyCol)
   );
GO

INSERT INTO dbo.OneVariable
VALUES(1);
GO 999

INSERT INTO dbo.OneVariable
VALUES(2);
UPDATE STATISTICS dbo.OneVariable
    WITH FULLSCAN;
GO

-- Now turn the execution plan plus run-time statistics on again
DECLARE @Data int = 1;
SELECT COUNT(*)
FROM   dbo.OneVariable
WHERE  DataCol = @Data;
GO

DECLARE @Data int = 2;
SELECT COUNT(*)
FROM   dbo.OneVariable
WHERE  DataCol = @Data;
GO



-- Inequality with variable: always 30%
DECLARE @ProductID int = 820;

SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID > @ProductID;
GO

DECLARE @ProductID int = 2000;

SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID > @ProductID;
GO

DECLARE @ProductID int = 0;

SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID > @ProductID;
GO

-- It even remains 30% when the statistics indicate just two distinct values
DECLARE @Data int = 1;
SELECT COUNT(*)
FROM   dbo.OneVariable
WHERE  DataCol > @Data;
GO
