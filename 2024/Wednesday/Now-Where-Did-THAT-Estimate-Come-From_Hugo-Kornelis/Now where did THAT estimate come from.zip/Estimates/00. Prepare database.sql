USE master;
GO

-- Remove old version of demo database. Use brute force if necessary.
IF EXISTS (SELECT * FROM sys.databases WHERE name = N'EstimateDemo')
  BEGIN;
  ALTER DATABASE EstimateDemo SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
  DROP DATABASE EstimateDemo;
  END;
GO

-- Create the empty demo database, with sufficient size for the demo tables.
-- To make the script run on all databases, I don't hardcode the directory,
-- but use the directory where the master database lives;
-- this gives me the guarantee that the directory exists
-- and is accessible by SQL Server.
--
-- Unfortunately, this requires the use of dynamic SQL,
-- which I normally avoid. In this case, though, the risk is acceptable.
-- The only way to exploit this dynamic SQL is to install an instance
-- with the master database in a directory with a carefully crafted pathname;
-- whoever can do that must have admin rights
-- and doesn't need the SQL injection attack.
DECLARE @master_directory nvarchar(260);
SET @master_directory =
 (SELECT REPLACE(physical_name, 'master.mdf', '')
  FROM   sys.database_files
  WHERE  name='master'
  AND    type=0);
EXECUTE
 (N'CREATE DATABASE EstimateDemo
    ON PRIMARY
      (NAME = EstimateDemo,
       FILENAME = ''' + @master_directory + N'EstimateDemo.mdf'',
       SIZE = 150MB)
    LOG ON
      (NAME = EstimateDemoLog,
       FILENAME = ''' + @master_directory + N'EstimateDemo.ldf'',
       SIZE = 150MB);');
GO

-- Switch to tempdb before switching to EstimateDemo.
-- If EstimateDemo was not created, the USE statement fails,
-- but the next batch will still execute.
-- Switching to tempdb first ensures spurious tables will be created there.

USE tempdb;
GO
USE EstimateDemo;
GO

CREATE TABLE dbo.DemoTable1
    (SalesOrderID       int NOT NULL,
     SalesOrderDetailID int NOT NULL,
     ProductID          int NOT NULL,
     CONSTRAINT pk_DemoTable1
         PRIMARY KEY (
         SalesOrderID,
         SalesOrderDetailID));

CREATE INDEX ix_Demo1_ProductID ON dbo.DemoTable1 (ProductID);
GO

CREATE TABLE dbo.DemoTable2
    (SalesOrderID       int NOT NULL,
     SalesOrderDetailID int NOT NULL,
     ProductID          int NOT NULL,
     CONSTRAINT pk_DemoTable2
         PRIMARY KEY (
         SalesOrderID,
         SalesOrderDetailID));

CREATE INDEX ix_Demo2_ProductID ON dbo.DemoTable2 (ProductID);
GO

-- Fill demo table 1 with three copies of SalesOrderDetail
INSERT  dbo.DemoTable1 (SalesOrderID,
                        SalesOrderDetailID,
                        ProductID)
SELECT  SalesOrderID,
        SalesOrderDetailID,
        ProductID
FROM    AdventureWorks2012.Sales.SalesOrderDetail
UNION ALL
SELECT  SalesOrderID - 40000,   -- To prevent duplicate key errors
        SalesOrderDetailID + 2,
        ProductID + 100         -- For some interesting variety in the data
FROM    AdventureWorks2012.Sales.SalesOrderDetail
UNION ALL
SELECT  SalesOrderID + 40000,   -- To prevent duplicate key errors
        SalesOrderDetailID + 4,
        ProductID + 200         -- For some interesting variety in the data
FROM    AdventureWorks2012.Sales.SalesOrderDetail;

-- Force update of statistics, use fullscan to get best possible results
UPDATE STATISTICS dbo.DemoTable1
WITH FULLSCAN;

-- Now delete 5% of the data - this does not trigger a statistics recompile
DELETE  dbo.DemoTable1
WHERE   SalesOrderDetailID % 20 = 1;

-- Fill demo table 2 with copy of demo table 1
INSERT  dbo.DemoTable2 (SalesOrderID,
                        SalesOrderDetailID,
                        ProductID)
SELECT  SalesOrderID,
        SalesOrderDetailID,
        ProductID
FROM    dbo.DemoTable1;

-- Force update of statistics for demo table 2, use fullscan to get best possible results
UPDATE STATISTICS dbo.DemoTable2
WITH FULLSCAN;
GO
