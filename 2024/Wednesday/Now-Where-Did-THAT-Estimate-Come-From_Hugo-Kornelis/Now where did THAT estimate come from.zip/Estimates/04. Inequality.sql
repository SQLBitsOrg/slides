USE EstimateDemo;
GO

SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID >= 1189
OPTION (RECOMPILE);

SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID >  1189
OPTION (RECOMPILE);

SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID >  1191
OPTION (RECOMPILE);

SELECT  COUNT(*)
FROM    dbo.DemoTable1
WHERE   ProductID >= 1191
OPTION (RECOMPILE);
GO
