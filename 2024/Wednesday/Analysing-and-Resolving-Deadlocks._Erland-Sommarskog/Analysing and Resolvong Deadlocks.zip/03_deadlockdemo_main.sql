﻿-- Demo for deadlock try. In the session, I only show the script to demonstrate
-- the complexity of deadlock retry. But if you want to see the deadlock and test
-- the retry, there are two accompanying scripts, 03_deadlockdemo2.sql and
-- 03_deadlockdemo3.sql that helps you to run the procedures in exact parallel
-- so that there will be a deadlock.
USE tempdb
go
DROP PROCEDURE IF EXISTS Deadlock_demo
go
DROP TABLE IF EXISTS TestTbl
CREATE TABLE TestTbl (id    int              NOT NULL,
                      guid  uniqueidentifier NOT NULL,
                      data1 datetime2(3)     NOT NULL,
                      data2 int              NOT NULL,
                      data3 sysname          NOT NULL,
                      CONSTRAINT pk_TestTbl PRIMARY KEY (id),
                      CONSTRAINT u_TestTbl UNIQUE (guid)
)

DROP TYPE IF EXISTS TblType
CREATE TYPE TblType AS TABLE (data1 datetime2(3)  NOT NULL,
                              data2 int           NOT NULL,
                              data3 sysname       NOT NULL)
go
-- This is the first version of the procedure which produces a 
-- deadlock with the SERIALIZEBLE hint and avoids it with the UPDLOCK hint.
CREATE OR ALTER PROCEDURE Deadlock_demo @data TblType READONLY AS
SET XACT_ABORT, NOCOUNT ON
BEGIN TRY
   DECLARE @firstid int

   DECLARE @guids TABLE (guid uniqueidentifier NOT NULL UNIQUE)

   BEGIN TRANSACTION

   -- With SERIALIZABLE, the procedure says "I don't want the max value
   -- to change while my transacton is active." If two sessions run the
   -- procedure in parallel they will deadlock. 
   SELECT @firstid = isnull(MAX(id), 0) + 1
   FROM   TestTbl WITH (SERIALIZABLE)
   -- WITH (UPDLOCK, SERIALIZABLE)    -- Use the UPDLOCK hint to prevent the deadlock.

   WAITFOR DELAY '00:00:00.250'    -- To increase the probability for deadlock.

   INSERT TestTbl(id, guid, data1, data2, data3)
      OUTPUT inserted.guid INTO @guids
      SELECT @firstid + row_number() OVER(ORDER BY data3) - 1, 
             newid(), data1, data2, data3
      FROM   @data

   COMMIT TRANSACTION

   -- Return data to client. In a real-world case, this could be a more 
   -- complex statement, which also could deadlock.
   SELECT T.*
   FROM   TestTbl T
   WHERE  EXISTS (SELECT * FROM @guids g WHERE T.guid = g.guid)
END TRY
BEGIN CATCH
   -- Standard CATCH handler.
   IF @@trancount > 0 ROLLBACK TRANSACTION
   ; THROW
END CATCH
go
-- To test the procedure: Open 03_deadlockdemo2.sql and follow
-- the instructions.

-------------------------------------------------------------------
-- The Deadlock_demo procedure, now with retry logic. The code becomes
-- considerably more complex.
CREATE OR ALTER PROCEDURE Deadlock_demo @data TblType READONLY AS
SET XACT_ABORT, NOCOUNT ON
BEGIN TRY
   DECLARE @firstid int,
           @trancount_save int = @@trancount

   DECLARE @guids TABLE (guid uniqueidentifier NOT NULL UNIQUE)

   DECLARE @trycnt int = 1,
           @done   bit = 0

   WHILE @done = 0
   BEGIN TRY
      SELECT @firstid = NULL
      DELETE @guids

      BEGIN TRANSACTION

      SELECT @firstid = isnull(MAX(id), 0) + 1
      FROM   TestTbl WITH (SERIALIZABLE)

      WAITFOR DELAY '00:00:00.250'   -- To increase the probability for deadlock.

      INSERT TestTbl(id, guid, data1, data2, data3)
         OUTPUT inserted.guid INTO @guids
         SELECT @firstid + row_number() OVER(ORDER BY data1) - 1, 
                newid(), data1, data2, data3
         FROM   @data

      -- Note that the SELECT must be inside the transaction if we want
      -- deadlock retry also for the SELECT.
      SELECT T.*
      FROM   TestTbl T
      WHERE  EXISTS (SELECT * FROM @guids g WHERE T.guid = g.guid)

      COMMIT TRANSACTION

      SELECT @done = 1    -- Exit loop.
   END TRY
   BEGIN CATCH
      IF @@trancount > 0 ROLLBACK TRANSACTION

      -- Do deadlock retry?
      IF @trancount_save = 0 AND error_number() = 1205 -- AND @trycnt < 5
      BEGIN
         PRINT concat('Deadlock in attempt ', @trycnt, ', retrying.')
         SELECT @trycnt = @trycnt + 1
      END
      ELSE
      BEGIN
         -- Not deadlock or retry not permissible. Re-raise the error.
         ; THROW
      END
   END CATCH
END TRY
BEGIN CATCH
   IF @@trancount > 0 ROLLBACK TRANSACTION
   ; THROW
END CATCH
go
